insert into members
values ('admin','admin1004','심tothe온','남', '1900/01/01', 'admin@pcm.com', '010-0000-0000', '부산광역시', '2000/01/01', 'A', 999999);

insert into products
values ('신라면',56,1000,2000,'라면');
insert into products
values ('참깨라면',80,1000,2000,'라면');
insert into products
values ('왕뚜껑',70,900,2000,'라면');
insert into products
values ('육개장',86,800,2000,'라면');
insert into products
values ('콜라',70,600,1000,'음료');
insert into products
values ('사이다',56,800,1000,'음료');
insert into products
values ('아이스티',98,700,1500,'음료');
insert into products
values ('오렌지주스',100,800,1500,'음료');
insert into products
values ('아메리카노',50,300,1500,'음료');
insert into products
values ('피자빵',40,800,1300,'빵류');
insert into products
values ('햄버거',75,800,1600,'빵류');
insert into products
values ('초코빵',66,500,900,'빵류');
insert into products
values ('도넛',50,600,1200,'빵류');
insert into products
values ('소보루빵',88,800,1300,'빵류');
insert into products
values ('우유식빵',77,1000,1700,'빵류');

insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(1, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(2, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(3, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(4, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(5, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(6, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(7, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(8, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(9, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(10, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(11, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(12, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(13, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(14, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(15, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(16, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(17, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(18, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(19, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(20, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(21, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(22, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(23, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(24, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(25, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(26, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(27, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(28, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(29, 'admin', 0, 'samsung','lg');
insert into seats(seat_no, member_id, condition, monitor, mainframe)
values(30, 'admin', 0, 'samsung','lg');
